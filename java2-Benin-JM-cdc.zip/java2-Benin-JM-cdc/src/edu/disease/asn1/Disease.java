package edu.disease.asn1;
import java.util.Objects;
import java.util.UUID;
public class Disease {
	UUID diseasedId;
	String name;
	public UUID getDiseasedId() {
		return diseasedId;
	}
	public void setDiseasedId(UUID diseasedId) {
		this.diseasedId = diseasedId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Disease [diseasedId=" + diseasedId + ", name=" + name + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(diseasedId);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Disease other = (Disease) obj;
		return Objects.equals(diseasedId, other.diseasedId);
	}
	
}
