package edu.disease.asn1;
import java.util.Objects;
import java.util.UUID;
import java.time.LocalDateTime;
public class Exposure {
	
	UUID patientId;
	LocalDateTime dateTime;
	String exposureType;
	
	public Exposure(UUID patientId) {
		this.patientId=patientId;
	}
	

	public UUID getPatientId() {
		return patientId;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}


	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}


	public String getExposureType() {
		return exposureType;
	}


	public void setExposureType(String exposureType) {
		
		if(exposureType.equals("I")){ //To accept indirect exposure
			this.exposureType = exposureType;
		}
		else if(exposureType.contentEquals("D")) { //To accept Direct exposure
			this.exposureType = exposureType;
		}
		else {
			try{
				throw new IllegalArgumentException();
			}
			catch(IllegalArgumentException e){
				e.printStackTrace();
				
			}
		}
	}


	@Override
	public int hashCode() {
		return Objects.hash(dateTime, patientId);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Exposure other = (Exposure) obj;
		return Objects.equals(dateTime, other.dateTime) && Objects.equals(patientId, other.patientId);
	}


	

	
	
}