package edu.disease.asn2;

import java.util.UUID;

abstract class Disease {
	UUID diseasedId;
	String name;

	abstract String getExamples();

	public UUID getDiseasedId() {
		return diseasedId;
	}

	public void setDiseasedId(UUID diseasedId) {
		this.diseasedId = diseasedId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

class InfectiousDisease extends Disease {

	@Override
	String getExamples() {
		String diseases[] = { "Influenza", "Malaria", "Measles", "COVID-19" };
		for (String disease : diseases) {
			return disease;
		}
		return null;
	}
}

class NonInfectiousDisease extends Disease {

	@Override
	String getExamples() {
		String diseases[] = { "Cancer", "Diabeties", "Stroke", "Asthma" };
		for (String disease : diseases) {
			return disease;
		}
		return "";
	}

}
