
package edu.disease.asn2;

import java.util.Iterator;
import java.util.UUID;

import edu.disease.asn1.Exposure;

public class DiseaseControlManagerImpl implements DiseaseControlManager {
	private Disease[] diseases;
	private Patient[] patients;
	int maxDiseases, maxPatients;
	int position = 0;
	Disease diseaseType;
	int position1 = 0;

	public DiseaseControlManagerImpl(int maxDiseases, int maxPatients) {
		if (maxDiseases > 0 && maxPatients > 0) {

			this.maxDiseases = maxDiseases;
			this.maxPatients = maxPatients;
			diseases = new Disease[maxDiseases];
			patients = new Patient[maxPatients];

		} else
			throw new IllegalArgumentException();
	}

	@Override
	public Disease addDisease(String name, Boolean infectious) {
		if (position != maxDiseases)
			if (infectious)
				return diseases[position++] = new InfectiousDisease();
			else
				return diseases[position++] = new NonInfectiousDisease();
		else
			throw new IllegalArgumentException();

	}

	@Override
	public Disease getDisease(UUID diseased) {
		for (int i = 0; i < maxDiseases; i++) {
			if (diseases[i].diseasedId.equals(diseased)) {
				return diseases[i];
			}
		}
		return null;

	}

	@Override
	public Patient addPatient(String firstName, String lastName, int maxDiseases, int maxExposures) {
		if (position1 < maxPatients) {
			patients[position1] = new Patient(maxDiseases, maxExposures);
			patients[position1].setFirstName(firstName);
			patients[position1].setLastName(lastName);
			return patients[position++];
		} else {
			throw new IllegalStateException("No space to add..");
		}
	}

	@Override
	public Patient getPatient(UUID patientId) {
		for (int i = 0; i < maxPatients; i++) {
			if (patients[i].patientId.equals(patientId))
				return patients[i];
		}
		return null;
	}

	@Override
	public void addDiseaseToPatient(UUID patientId, UUID diseaseId) {
		Patient patient = getPatient(patientId);
		Disease disease = getDisease(diseaseId);
		if (patient == null) {
			throw new IllegalArgumentException("Enter a valid ID");
		}
		if (disease == null) {
			throw new IllegalArgumentException("Enter a valid ID");
		}
		patient.addDiseaseId(disease.getDiseasedId());

	}

	@Override
	public void addExposureToPatient(UUID patientId, Exposure exposure) {
		Patient patient = getPatient(patientId);
		if (patient == null) {
			throw new IllegalArgumentException("Enter a valid ID");
		}
		patient.addExposure(exposure);

	}
}
