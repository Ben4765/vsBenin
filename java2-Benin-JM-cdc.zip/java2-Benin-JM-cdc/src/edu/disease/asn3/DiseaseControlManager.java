package edu.disease.asn3;

import java.util.UUID;
/**
 * The DiseaseControlManager interface has abstract methods for managing diseases and patients.
 */
public interface DiseaseControlManager {
	 /**
     * Adds a new Disease with the given name and infectious status.
     *
     * @param name       The name of the disease.
     * @param infectious The infectious type of disease.
     * @return The new Disease object.
     */
	Disease addDisease(String name, Boolean infectious);
	 /**
     * Retrieves a Disease object using its unique identifier (UUID).
     *
     * @param diseaseId The unique identifier of the disease.
     * @return The Disease object corresponding to the provided UUID, or null if not found.
     */
	Disease getDisease(UUID diseased);

    /**
     * Adds a new Patient with the given first name, last name, maximum diseases, and maximum exposures.
     *
     * @param firstName    The first name of the patient.
     * @param lastName     The last name of the patient.
     * @param maxDiseases  The maximum number of diseases.
     * @param maxExposures The maximum number of exposures.
     * @return The added Patient object.
     */
	Patient addPatient(String firstName, String lastName, int maxDiseases, int maxExposures);
	   /**
     * Retrieves a Patient object using its unique identifier (UUID).
     *
     * @param patientId The unique identifier of the patient.
     * @return The Patient object corresponding to the provided UUID, or null if not found.
     */
	Patient getPatient(UUID patientId);

	void addDiseaseToPatient(UUID patientId, UUID diseaseId);

	void addExposureToPatient(UUID patientId, Exposure exposure);

	Disease[] getDiseases();

	Patient[] getPatients();

}
