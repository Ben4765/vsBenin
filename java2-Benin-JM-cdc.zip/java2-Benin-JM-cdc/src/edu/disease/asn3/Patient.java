package edu.disease.asn3;

import java.io.Serializable;
import java.util.UUID;

public class Patient implements Comparable<Patient>, Serializable  {
	UUID patientId;
	String firstName;
	String lastName;
	Exposure[] exposures;
	UUID[] diseaseIds;
	int c = 0; // Counter variable
	int d = 0; // Counter variable

	public Patient(int maxDiseases, int maxExposures) {
		try {
			if (maxDiseases > 0 && maxExposures > 0) {
				exposures = new Exposure[maxExposures];
				diseaseIds = new UUID[maxDiseases];
			} else
				throw new IllegalArgumentException();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
	}

	public void addDiseaseId(UUID diseaseId) {

		try {
			if (c == diseaseIds.length)
				throw new IndexOutOfBoundsException();
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		diseaseIds[c] = diseaseId;
		c++;
	}

	public void addExposure(Exposure exposure) {
		try {
			if (d == exposures.length)
				throw new IndexOutOfBoundsException();
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		exposures[d] = exposure;
		d++;
	}

	public UUID getPatientId() {
		return patientId;
	}

	public void setPatientId(UUID patientId) {
		this.patientId = patientId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public int compareTo(Patient o) {
		// Compare last names first
		int lastNameComparison = this.lastName.compareToIgnoreCase(o.lastName);

		if (lastNameComparison == 0) {
			// If last names are the same, compare first names
			return this.firstName.compareToIgnoreCase(o.firstName);
		}

		return lastNameComparison;
	}

}
