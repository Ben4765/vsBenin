package edu.disease.asn1;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

class PatientTest {

	@Test
	void testPatient() {
		fail("Not yet implemented");
	}

	@Test
	void testAddDiseaseId() {
		fail("Not yet implemented");
	}

	@Test
	void testAddExposure() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPatientId() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPatientId() {
		fail("Not yet implemented");
	}

	@Test
	void testGetFirstName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetFirstName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetLastName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetLastName() {
		fail("Not yet implemented");
	}

}
