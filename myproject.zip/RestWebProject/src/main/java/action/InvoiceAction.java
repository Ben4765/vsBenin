package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InvoiceAction extends Action{

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		
		return null;
	}

}
