
package action;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.ServletContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LangAction extends Action{
	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		String language=req.getParameter("language");
		ResourceBundle rb=ResourceBundle.getBundle("dictionary",new Locale(language));
		ServletContext application=req.getServletContext();
		application.setAttribute("rb", rb);
		return "lang.success";
	}
}
