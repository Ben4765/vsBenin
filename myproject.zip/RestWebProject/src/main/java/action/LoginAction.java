package action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ItemMasterDTO;
import service.LoginServiceImpl;
import service.LoginServiceInter;

public class LoginAction extends Action {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		LoginServiceInter service = new LoginServiceImpl();
		String name = req.getParameter("uname");
		String password = req.getParameter("upass");

		if (service.validate(name, password)) {
			if (service.checkFlag(name)) {
				HttpSession session = req.getSession();
				session.setAttribute("name", name);
				List<String> list=new ArrayList<>(); 
				session.setAttribute("list", list);
				service.updateFlag(name,1);
				return "login.success";
			}
		}
		return "login.fail";
	}

}
