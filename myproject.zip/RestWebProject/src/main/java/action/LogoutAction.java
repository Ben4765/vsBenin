package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.LoginServiceImpl;

public class LogoutAction extends Action{

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session=req.getSession();
		String user=session.getAttribute("name").toString();
//		String user=req.getParameter("name");
		LoginServiceImpl logout=new LoginServiceImpl();
		logout.updateFlag(user,0);
		return "logout.success";
		
	}

}
