package action;

import java.sql.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAOImpl;
import dao.UserDAOInter;
import dao.UserDTO;

public class RegisterAction extends Action {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		
		try {
			UserDTO user = new UserDTO();
			user.setFirstName(req.getParameter("fname"));
			user.setLastName(req.getParameter("lname"));
			user.setuName(req.getParameter("uname"));
			user.setuPass(req.getParameter("upass"));
			user.setGmail(req.getParameter("gmail"));
			user.setDate(Date.valueOf(req.getParameter("date")));
			user.setPhone(Long.parseLong(req.getParameter("phone")));
			user.setFlag(0);
			
			UserDAOInter userConfig = new UserDAOImpl();
			
			userConfig.insertCustomer(user);
			System.out.println("Registered successfully...");
			return "register.success";
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
		
	}

}
