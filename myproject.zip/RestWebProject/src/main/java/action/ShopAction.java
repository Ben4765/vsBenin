package action;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.InvoiceMasterDAOImpl;
import dao.InvoicemasterDTO;
import dao.ItemMasterDAO;
import dao.ItemMasterDAOImpl;
import dao.ItemMasterDTO;

public class ShopAction extends Action {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {

		ItemMasterDAO shop = new ItemMasterDAOImpl();
		HttpSession session = req.getSession();
		System.out.println(session.getAttribute("name").toString());
		String uname = session.getAttribute("name").toString();
		InvoiceMasterDAOImpl invmaster=new InvoiceMasterDAOImpl();
		Enumeration<String> parameters = req.getParameterNames();
		System.out.println("parameters" + parameters.toString());
		List<String> list = (List<String>)req.getAttribute("list");
		if(list==null) {
			list=new ArrayList<String>();
		}
		while (parameters.hasMoreElements()) {

			String name = parameters.nextElement();
			System.out.println("par names... " + name);
			list.add(name);
		}
		session.setAttribute("list", list);
		System.out.println(list);
		return "shop.success";
	}

}
