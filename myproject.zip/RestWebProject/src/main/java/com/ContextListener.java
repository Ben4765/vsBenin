package com;

import java.io.FileInputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class ContextListener
 *
 */
@WebListener
public class ContextListener implements ServletContextListener {

	/**
	 * Default constructor.
	 */
	public ContextListener() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see ServletContextListener#contextDestroyed(ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
	}

	/**
	 * @see ServletContextListener#contextInitialized(ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent sce) {
		try {
			System.out.println("Context initialized");
			ServletContext application = sce.getServletContext();

			String path = application.getRealPath("/WEB-INF/serverConfig.properties");
			Properties server = new Properties();
			server.load(new FileInputStream(path));
			application.setAttribute("server", server);

			String path1 = application.getRealPath("/WEB-INF/dbConfig.properties");
			Properties p1 = new Properties();
			p1.load(new FileInputStream(path1));

			
			String driver = p1.getProperty("driver");

			Class.forName(driver);
			ConnectionUtility.username = p1.getProperty("username");
			ConnectionUtility.password = p1.getProperty("password");
			ConnectionUtility.url = p1.getProperty("url");
			
//			ResourceBundle rb=ResourceBundle.getBundle("dictionary",new Locale("en"));
//			application.setAttribute("rb", rb);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
