package com;

import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;

public class RequestProcessor {
	public String process(HttpServletRequest req, HttpServletResponse res) {
		try {
			HttpSession session=req.getSession();
			session.setMaxInactiveInterval(60);
			ServletContext application = req.getServletContext();

			Properties server = (Properties) application.getAttribute("server");

			String form = req.getAttribute("formid").toString(); // lang

			String value = server.getProperty(form);// action.LangAction

			Action action = (Action) Class.forName(value).getConstructor().newInstance();

			String result = action.execute(req, res);// lang.success
			System.out.println(result);

			String nextpage = server.getProperty(result);// login.jsp

//			RequestDispatcher rd = req.getRequestDispatcher(nextpage);
//			rd.forward(req, res);
			return result;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
