package dao;

import java.sql.Date;
import java.util.List;

public interface InvoiceMasterDAO {
	public InvoicemasterDTO findByDate(Date date);
	public void addInvoice(String uname,ItemMasterDTO item);
	public List<InvoicemasterDTO> findByUName(String uname);
}
