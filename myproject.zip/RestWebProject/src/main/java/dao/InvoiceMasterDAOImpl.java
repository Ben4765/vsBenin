package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.ConnectionUtility;

public class InvoiceMasterDAOImpl implements InvoiceMasterDAO {

	@Override
	public InvoicemasterDTO findByDate(Date date) {
		try {
			Connection con = ConnectionUtility.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from invoicemaster where pdate=?");
			ps.setDate(1, date);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				InvoicemasterDTO invoice = new InvoicemasterDTO();

				invoice.setuName(rs.getString(1));
				invoice.setDate(rs.getDate(2));
				invoice.setItemId(rs.getInt(3));
				invoice.setItemName(rs.getString(4));
				invoice.setPrice(rs.getFloat(5));
				return invoice;
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return null;
	}

	@Override
	public void addInvoice(String uname, ItemMasterDTO item) {
		try {
			Connection con = ConnectionUtility.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into invoicemaster values(?,?,?,?,?)");
			ps.setString(1, uname);
			ps.setDate(2, Date.valueOf(LocalDate.now()));
			ps.setInt(3, item.getItemId());
			ps.setString(4, item.getItemName());
			ps.setFloat(5, item.getPrice());
			ps.executeUpdate();
			ConnectionUtility.closeConnection(null, null);
		} catch (Exception e) {
			e.printStackTrace();

			ConnectionUtility.closeConnection(e, null);
		}

	}

	@Override
	public List<InvoicemasterDTO> findByUName(String uname) {
		try {
			Connection con = ConnectionUtility.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from invoicemaster where uname=?");
			ps.setString(1, uname);
			ResultSet rs = ps.executeQuery();
			List<InvoicemasterDTO> list = new ArrayList<>();
			while (rs.next()) {
				InvoicemasterDTO invoice = new InvoicemasterDTO();
				invoice.setuName(rs.getString(1));
				invoice.setDate(rs.getDate(2));
				invoice.setItemId(rs.getInt(3));
				invoice.setItemName(rs.getString(4));
				invoice.setPrice(rs.getFloat(5));
				list.add(invoice);
			}
			return list;

		} catch (Exception e) {

			e.printStackTrace();
		}
		return null;
	}

}
