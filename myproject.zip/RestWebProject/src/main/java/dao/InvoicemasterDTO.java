package dao;

import java.sql.Date;

public class InvoicemasterDTO {
	private String uName, itemName;
	private int itemId;
	private float price;private Date date;

	

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "InvoicemasterDTO [uName=" + uName + ", itemName=" + itemName + ", itemId=" + itemId + ", price=" + price
				+ ", date=" + date + "]";
	}
	
}
