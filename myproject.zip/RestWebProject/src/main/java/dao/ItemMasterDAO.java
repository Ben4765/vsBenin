package dao;

import java.util.List;

public interface ItemMasterDAO {
	public ItemMasterDTO findByItemId(int id);
	public List<ItemMasterDTO> findAll(int id);
	public boolean insertItem(ItemMasterDTO item);
	public boolean deleteItem(ItemMasterDTO item);
}
