package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.ConnectionUtility;

public class ItemMasterDAOImpl implements ItemMasterDAO {

	@Override
	public ItemMasterDTO findByItemId(int itemId) {
		try {
			Connection con = ConnectionUtility.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from itemmaster where itemId=?");
			ps.setInt(1, itemId);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ItemMasterDTO item = new ItemMasterDTO();
				item.setItemId(rs.getInt(1));
				item.setItemName(rs.getString(2));
				
				item.setPrice(rs.getFloat(4));
				item.setShopId(rs.getInt(5));
				return item;
			}
			ConnectionUtility.closeConnection(null, null);

		} catch (Exception e) {

			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<ItemMasterDTO> findAll(int id) {
		try {
			Connection con = ConnectionUtility.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from itemmaster where shopid=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			List<ItemMasterDTO> list = new ArrayList<ItemMasterDTO>();
			while (rs.next()) {
				ItemMasterDTO item = new ItemMasterDTO();
				item.setItemId(rs.getInt(1));
				item.setItemName(rs.getString(2));
				item.setPrice(rs.getFloat(4));
				item.setShopId(rs.getInt(5));
				list.add(item);

			}
			ConnectionUtility.closeConnection(null, null);
			return list;

		} catch (Exception e) {
			ConnectionUtility.closeConnection(e, null);
		}

		return null;
	}

	@Override
	public boolean insertItem(ItemMasterDTO item) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteItem(ItemMasterDTO item) {
		// TODO Auto-generated method stub
		return false;
	}

}
