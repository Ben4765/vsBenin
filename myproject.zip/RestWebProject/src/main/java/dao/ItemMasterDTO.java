package dao;

public class ItemMasterDTO {
	private int itemId, shopId;
	private float price;
	private String itemName;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	@Override
	public String toString() {
		return "ItemMasterDTO [itemId=" + itemId + ", shopId=" + shopId + ", price=" + price + ", itemName=" + itemName
				+ "]";
	}
}
