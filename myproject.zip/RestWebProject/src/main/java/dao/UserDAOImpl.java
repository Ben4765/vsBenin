package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ConnectionUtility;

public class UserDAOImpl implements UserDAOInter {
	public UserDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public UserDTO findByName(String uName) {
		try {
			Connection con = ConnectionUtility.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from userdetails where uname=?");
			ps.setString(1, uName);
			ResultSet rs = ps.executeQuery();
			UserDTO user = new UserDTO();

			if (rs.next()) {
				user.setFirstName(rs.getString(1));
				user.setLastName(rs.getString(2));
				user.setuName(rs.getString(3));
				user.setuPass(rs.getString(4));
				user.setGmail(rs.getString(5));
				user.setDate(rs.getDate(6));
				user.setPhone(rs.getLong(7));
				user.setFlag(rs.getInt(8));
				return user;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int insertCustomer(UserDTO dto) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("insert into userdetails values(?,?,?,?,?,?,?,?)");
			ps.setString(1, dto.getFirstName());
			ps.setString(2, dto.getLastName());
			ps.setString(3, dto.getuName());
			ps.setString(4, dto.getuPass());
			ps.setString(5, dto.getGmail());
			ps.setDate(6, (Date) dto.getDate());
			ps.setLong(7, dto.getPhone());
			ps.setInt(8, dto.getFlag());
			int n = ps.executeUpdate();
			ConnectionUtility.closeConnection(null, null);
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public void updateCustomer(UserDTO dto) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("select * from userdetails where uname=?");
			ps.setString(1, dto.getuName());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ps = con.prepareStatement(
						"update userdetails set firstname=?,lastname=?,uname=?, upass=?, gmail=?, dob=?, phone=?,flag=? where uname=?");
				ps.setString(1, dto.getFirstName());
				ps.setString(2, dto.getLastName());
				ps.setString(3, dto.getuName());
				ps.setString(4, dto.getuPass());
				ps.setString(5, dto.getGmail());
				ps.setDate(6, (Date) dto.getDate());
				ps.setLong(7, dto.getPhone());
				ps.setInt(8, dto.getFlag());
				ps.setString(9, dto.getuName());
				

				ps.executeUpdate();
			} else {
				
			}
			ConnectionUtility.closeConnection(null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public boolean deleteCustomer(UserDTO dto) {
		PreparedStatement ps;
		try {
			Connection con = ConnectionUtility.getConnection();
			ps = con.prepareStatement("delete from userdetails where uname=?");
			ps.setString(1, dto.getuName());
			ps.executeUpdate();
			ConnectionUtility.closeConnection(null, null);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
