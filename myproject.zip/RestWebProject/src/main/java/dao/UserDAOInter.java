package dao;

public interface UserDAOInter {
	public UserDTO findByName(String uName);
	public int insertCustomer(UserDTO dto);
	public void updateCustomer(UserDTO dto);
	public boolean deleteCustomer(UserDTO dto);
	
}
