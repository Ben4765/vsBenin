package dao;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

public class UserDTO implements Serializable {
	private Date date;
	private String firstName, lastName, uName, uPass, gmail;
	long phone;
	private int flag;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public String getuPass() {
		return uPass;
	}

	public void setuPass(String uPass) {
		this.uPass = uPass;
	}

	public String getGmail() {
		return gmail;
	}

	public void setGmail(String gmail) {
		this.gmail = gmail;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	@Override
	public String toString() {
		return "UserDTO [date=" + date + ", firstName=" + firstName + ", lastName=" + lastName + ", uName=" + uName
				+ ", uPass=" + uPass + ", gmail=" + gmail + ", phone=" + phone + ", flag=" + flag + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(gmail, uName, uPass);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserDTO other = (UserDTO) obj;
		return Objects.equals(gmail, other.gmail) && Objects.equals(uName, other.uName)
				&& Objects.equals(uPass, other.uPass);
	}

}
