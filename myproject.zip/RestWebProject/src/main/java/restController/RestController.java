package restController;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.catalina.Session;

import com.RequestProcessor;
import dao.InvoiceMasterDAO;
import dao.InvoiceMasterDAOImpl;
import dao.InvoicemasterDTO;
import dao.ItemMasterDAO;
import dao.ItemMasterDAOImpl;
import dao.ItemMasterDTO;

@Path("api")
public class RestController {
	RequestProcessor rp;
	
	public RestController() {
		rp=new RequestProcessor();
	}

	@Context
	private HttpServletRequest request;

	@Context
	private HttpServletResponse response;
	
	@POST
	@Path("lang")
	public String lang(@FormParam("language") String lang) {
		request.setAttribute("formid", "lang");
		String result= rp.process(request, response);
		return result;
	}

	@POST
	@Path("login")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String login(@FormParam("uname")String username, @FormParam("upass") String password) {
		request.setAttribute("formid", "login");
		String result=rp.process(request, response);
		return result;
		
		
	}
	
	@POST
	@Path("logout")
	public String logout() {
		request.setAttribute("formid", "logout");
		String result=rp.process(request, response);
		return result;
		
	}
	@POST
	@Path("register")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String register(){
    	request.setAttribute("formid", "register");
    	String result=rp.process(request, response);
    	return result;
    	
    	
    }
	@POST
	@Path("shop")
	@Produces(MediaType.TEXT_HTML)
//	@Consumes(MediaType.APPLICATION_FORM_URLENCODED_TYPE)
	public String shop() {
		request.setAttribute("formid", "shop");
		String result=rp.process(request, response);
		System.out.println("result"+result);
		return result;
	}
	
	@GET
	@Path("Orders")
	@Produces(MediaType.APPLICATION_JSON)
	public List orders() {
		HttpSession session=request.getSession();
		InvoiceMasterDAO invoiceDAO=new InvoiceMasterDAOImpl();
		System.out.println(session.getAttribute("name"));
		List list =invoiceDAO.findByUName(session.getAttribute("name").toString());
		System.out.println(" invoice List "+list);
		return list;
	}
	@GET
	@Path("cart")
	@Produces(MediaType.APPLICATION_JSON)
	public List cart() {
		HttpSession session=request.getSession();
		List<String> list=(List<String>)session.getAttribute("list");
		System.out.println(list);
		List<ItemMasterDTO> items =new ArrayList<ItemMasterDTO>();
		ItemMasterDAO itemMaster=new ItemMasterDAOImpl();
		for(String id:list) {
			int itemId=Integer.parseInt(id);
			ItemMasterDTO item=itemMaster.findByItemId(itemId);
			items.add(item);
		}
		return items;
		
		
		
	}
	
	
}
