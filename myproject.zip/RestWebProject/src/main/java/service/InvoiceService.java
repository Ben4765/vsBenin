package service;

import java.util.List;

import dao.ItemMasterDTO;

public interface InvoiceService {
	public void additems(String uname,List<ItemMasterDTO> items);
}
