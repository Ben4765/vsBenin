package service;

import java.util.List;

import dao.InvoiceMasterDAO;
import dao.InvoiceMasterDAOImpl;
import dao.InvoicemasterDTO;
import dao.ItemMasterDAO;
import dao.ItemMasterDAOImpl;
import dao.ItemMasterDTO;

public class InvoiceServiceImpl implements InvoiceService{

	@Override
	public void additems(String uname, List<ItemMasterDTO> items) {
		InvoicemasterDTO invoice=new InvoicemasterDTO();
		ItemMasterDAO itemmasterDAO=new ItemMasterDAOImpl();
		
		InvoiceMasterDAO invoiceDAO=new InvoiceMasterDAOImpl();
		for(ItemMasterDTO item:items) {
			
		}
//		ItemMasterDTO item= itemmasterDAO.findByItemName(uname);
		
		
		
	}

}
