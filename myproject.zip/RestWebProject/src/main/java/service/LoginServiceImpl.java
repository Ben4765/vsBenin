package service;

import dao.UserDAOImpl;
import dao.UserDAOInter;
import dao.UserDTO;

public class LoginServiceImpl implements LoginServiceInter {

	@Override
	public boolean validate(String name, String pass) {
		try {
			UserDAOInter userDto = new UserDAOImpl();
			UserDTO user = userDto.findByName(name);
			if (user != null) {
				if (user.getuPass().equals(pass)) {
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean checkFlag(String uname) {
		try {
			UserDAOInter userDto = new UserDAOImpl();
			UserDTO user = userDto.findByName(uname);
			if (user.getFlag() == 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	@Override
	public void updateFlag(String uname, int flag) {
		try {
			UserDAOImpl userDao = new UserDAOImpl();
			UserDTO user = userDao.findByName(uname);
			user.setFlag(flag);
			userDao.updateCustomer(user);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
