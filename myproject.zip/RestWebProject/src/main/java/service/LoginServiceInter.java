package service;

public interface LoginServiceInter {
	public boolean validate(String uname,String upass);
	public boolean checkFlag(String uname);
	public void updateFlag(String uname, int flag);

}
