document.addEventListener("DOMContentLoaded",function(){
function logout() {
    const apiUrl = 'http://localhost:8080/RestWebProject/rest/api/logout';
    fetch(apiUrl, {
        method: 'POST',
    }
    )
        .then((response) => {
            if (!response.ok) {
                console.log(response.type);
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then((data) => {

            if (data == "logout.success") {
                console.log('Response data:', data);
                window.location.href = "login.html";
            }
        })
        .catch((error) => {
            // Handle any errors that occurred during the fetch
            console.log(error);
            window.alert('Fetch error:', error);

        });
}
})