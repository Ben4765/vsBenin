package database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.Properties;

public class ConnectionConfig {
	static String driver, username, password, url;

	private ConnectionConfig() {
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream("Configuration.properties"));
			driver = prop.getProperty("driver");
			username = prop.getProperty("user");
			password = prop.getProperty("pass");
			url = prop.getProperty("url");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static ThreadLocal<Connection> tl = new ThreadLocal<Connection>();
	static {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	synchronized public static Connection getConnection() throws SQLException {
		Connection con = tl.get();
		if (con == null) {
			con = DriverManager.getConnection(url, username, password);
			tl.set(con);
			return con;
		} else {
			return con;
		}
	}

	public static void closeConnection(Exception e, Savepoint s) throws SQLException {
		Connection con = tl.get();
		if (con == null) {
			System.out.println("No connections");
		} else {
			try {

				if (e == null) {
					con.commit();
				}
				if (s != null) {
					con.rollback(s);
					con.commit();
				} else
					con.rollback();
				con.close();
				tl.remove();
			} catch (Exception e2) {
				e.printStackTrace();
			}
		}
	}

}
