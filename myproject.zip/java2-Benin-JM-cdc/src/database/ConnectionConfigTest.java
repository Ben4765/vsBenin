package database;

import java.sql.Connection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConnectionConfigTest {
	public static void main(String[] args) {
		ExecutorService es = Executors.newFixedThreadPool(1);
		es.execute(() -> {
			try {
				Connection con = ConnectionConfig.getConnection();
				System.out.println(con);

			} catch (Exception e) {
				// TODO: handle exception
			}
		});
		es.execute(() -> {
			try {
				
				Connection con = ConnectionConfig.getConnection();
				
				System.out.println(con);
				ConnectionConfig.closeConnection();
			} catch (Exception e) {
				// TODO: handle exception
			}
		});
		es.execute(() -> {
			try {
				Connection con = ConnectionConfig.getConnection();
				System.out.println(con);
			} catch (Exception e) {
				// TODO: handle exception
			}
		});
		
es.shutdown();
	}
}
