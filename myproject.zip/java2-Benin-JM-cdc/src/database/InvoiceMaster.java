package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

import com.ConnectionUtility;


 class Invoice {
	private int invoice_id, discount;
	private Date invoice_date;
	public int getInvoice_id() {
		return invoice_id;
	}
	public void setInvoice_id(int invoice_id) {
		this.invoice_id = invoice_id;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public Date getInvoice_date() {
		return invoice_date;
	}
	public void setInvoice_date(Date invoice_date) {
		this.invoice_date = invoice_date;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + invoice_id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		if (invoice_id != other.invoice_id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "InvoiceMaster [invoice_id=" + invoice_id + ", discount=" + discount + ", invoice_date=" + invoice_date
				+ "]";
	}
}
public class InvoiceMaster{
	public static void main(String[] args) throws Exception {
		ArrayList<Invoice> list=new ArrayList<Invoice>();
		Connection con=ConnectionUtility.getConnection();
		String s="Select * from Invoicemaster where INVOICE_ID=?";
		PreparedStatement ps=con.prepareStatement(s);
		ps.setInt(1, 1);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			Invoice iv=new Invoice ();
			iv.setInvoice_id(rs.getInt(1));
			iv.setInvoice_date(rs.getDate(2));
			iv.setDiscount(rs.getInt(3));
			list.add(iv);
		}
		System.out.println(list.get(0));
		
	}
	
}
