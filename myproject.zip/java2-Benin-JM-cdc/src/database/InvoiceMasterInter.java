package database;

import java.sql.Date;
import java.util.ArrayList;

interface InvoiceMasterInter {
	public ArrayList<Invoice> findall();
	public int create(Invoice e);
	public int deleteById(int id);
	public int updateDateById(int id);
	public Date findDateById(int id);
	public int updateDiscountById(int id);	
}
