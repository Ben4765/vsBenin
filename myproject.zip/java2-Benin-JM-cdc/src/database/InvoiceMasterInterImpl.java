package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class InvoiceMasterInterImpl implements InvoiceMasterInter {

	@Override
	public ArrayList<Invoice> findall() throws SQLException {
		Connection con=ConnectionConfig.getConnection();
		PreparedStatement ps=con.prepareStatement("select* from InvoiceMaster");
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			con.
		}
	}

	@Override
	public int create(Invoice e) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteById(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateDateById(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Date findDateById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateDiscountById(int id) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
