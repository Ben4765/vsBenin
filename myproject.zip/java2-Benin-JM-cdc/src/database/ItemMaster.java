package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.ConnectionUtility;

import java.sql.Blob;

public class ItemMaster {
	public static void main(String[] args) throws Exception {
		ArrayList<Item> list = new ArrayList<Item>();
		Connection con = ConnectionUtility.getConnection();
		String s = "Select * from itemmaster where INVOICE_ID=?";
		PreparedStatement ps = con.prepareStatement(s);
		ps.setInt(1, 1);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			Item i = new Item();
			i.setItemId(rs.getInt(1));
			i.setItemName(rs.getString(2));
			i.setUnit(rs.getString(3));
			i.setPrice(rs.getFloat(4));
			i.setImage(rs.getBlob(5));

		}
	}
}

class Item {
	int itemId;
	String itemName, unit;
	float price;
	Blob image;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Blob getImage() {
		return image;
	}

	public void setImage(Blob image) {
		this.image = image;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + itemId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (itemId != other.itemId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", unit=" + unit + ", price=" + price + ", image="
				+ image + "]";
	}

}
