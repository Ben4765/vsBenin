package database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ReadAndWriteDemo {
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String user,pass,url,driver;
		Properties prop= new Properties();
		prop.load(new FileInputStream("Config.properties"));
		user=prop.getProperty("user");
		pass=prop.getProperty("pass");
		url=prop.getProperty("url");
		driver=prop.getProperty("driver");
		System.out.println(user +" : "+ pass +" : "+ url + " : "+driver);
		
		Connection con=DriverManager.getConnection(url,user,pass);
		System.out.println(con);
		
//		Connection con=DriverManager.getConnection(url)
	}
}
