package database;

import java.util.*;

class Student implements Comparable<Student> {
	private String name;
	private int rollNumber;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public Student(String name, int rollNumber) {
		this.name = name;
		this.rollNumber = rollNumber;
	}

	@Override
	public int compareTo(Student otherStudent) {
		return this.rollNumber - otherStudent.rollNumber;
	}

// Getters and other methods...
}

class ComparableExample {
	public static void main(String[] args) {
		List<Student> students = new ArrayList<>();
		students.add(new Student("Alice", 3));
		students.add(new Student("Bob", 2));
		students.add(new Student("Charlie", 1));

		Collections.sort(students);

		for (Student student : students) {
			System.out.println(student.getName() + " " + student.getRollNumber());
		}
	}
}