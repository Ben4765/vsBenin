package edu.disease.asn1;

import java.util.Arrays;
import java.util.Objects;
import java.util.UUID;

import edu.disease.asn1.Exposure;

public class Patient {
	private UUID patientId;
	private String firstName;
	private String lastName;
	private Exposure[] exposures;

	public Exposure[] getExposures() {
		return exposures;
	}

	public UUID[] getDiseaseIds() {
		return diseaseIds;
	}

	private UUID[] diseaseIds;
	int c = 0;
	int d = 0;

	public Patient(int maxDiseases, int maxExposures) {
		if (maxDiseases > 0 && maxExposures > 0) {
			exposures = new Exposure[maxExposures];
			diseaseIds = new UUID[maxDiseases];
		} else
			throw new IllegalArgumentException();

	}

	public void addDiseaseId(UUID diseaseId) {

		for (int i = 0; i < this.diseaseIds.length; i++) {
			if (this.diseaseIds[i] == null) {
				this.diseaseIds[i] = diseaseId;
				break;
			}
			if (i == this.diseaseIds.length - 1) {
				throw new IndexOutOfBoundsException("diseaseId array is full");
			}
		}
	}

	public void addExposure(Exposure exposure) {
////		
		for (int i = 0; i < this.exposures.length; i++) {
			if (this.exposures[i] == null) {
				this.exposures[i] = exposure;
				break;
			}
			if (i == this.exposures.length - 1) {
				throw new IndexOutOfBoundsException("exposures array is full");
			}
		}
	}

	public UUID getPatientId() {
		return patientId;
	}

	public void setPatientId(UUID patientId) {
		this.patientId = patientId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", exposures=" + Arrays.toString(exposures) + ", diseaseIds=" + Arrays.toString(diseaseIds) + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(patientId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Patient other = (Patient) obj;
		if (patientId == null) {
			if (other.patientId != null)
				return false;
		} else if (!patientId.equals(other.patientId))
			return false;
		return true;
	}

}
