package edu.disease.asn1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.UUID;



public class PatientTest {
	public static void main(String[] args) throws IOException {
		Patient p=new Patient(2, 2);
		//p.addDiseaseId(UUID.randomUUID());
		p.addExposure(new Exposure(UUID.randomUUID()));
		p.addExposure(new Exposure(UUID.randomUUID()));
		p.addExposure(new Exposure(UUID.randomUUID()));
		Exposure[] e =p.getExposures();
		for(Exposure e1:e) {
			System.out.println(e1);
		}
//		p.equals();
//		p.getFirstName();
//		p.getLastName();
//		p.getPatientId();
//		p.setPatientId(null);p.setFirstName(null);
//		p.getLastName();
//		p.setLastName(null);
//		p.hashCode();
//		p.toString();
	}
}
