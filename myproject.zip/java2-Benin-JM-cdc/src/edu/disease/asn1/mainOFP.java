package edu.disease.asn1;

import java.io.IOException;
import java.util.UUID;

public class mainOFP {
	public static void main(String[] args) throws IOException {
//		Patient p=new Patient(2, 2);
//		p.addDiseaseId(UUID.randomUUID());
//		p.addExposure(new Exposure(UUID.randomUUID()));
//		Exposure[] e =p.getExposures();
//		for(Exposure e1:e) {
//			System.out.println(e1);
//		}
		
	}
	
}
