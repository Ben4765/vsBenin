package edu.disease.asn2;

import java.util.UUID;

import edu.disease.asn3.Exposure;
import edu.disease.asn3.Patient;

public interface DiseaseControlManager {
	Disease addDisease(String name,Boolean infectious);
	Disease getDisease(UUID diseased);
	Patient addPatient(String firstName,String lastName,int maxDiseases,int maxExposures);
	Patient getPatient(UUID patientId);
	void addDiseaseToPatient(UUID patientId, UUID diseaseId);
	void addExposureToPatient(UUID patientId, Exposure exposure);
	
}
