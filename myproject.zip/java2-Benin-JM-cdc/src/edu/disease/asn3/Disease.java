
package edu.disease.asn3;

import java.io.Serializable;
import java.util.UUID;
/**
 * The Disease class contains the methods to get and set the diseaseId and the name.
 * @author Dell
 *
 */
abstract class Disease implements Serializable {
	
	UUID diseasedId;
	String name;

/**
 * 
 * @return
 */
	abstract String getExamples();
/**
 * 
 * the getDiseaseId returns the disease id for the current object.
 * @return
 */
	public UUID getDiseasedId() {
		return diseasedId;
	}
/**
 * The setDiseaseId initializes the diseaseId with the provided disease id of type UUID.
 * @param diseasedId
 */
	public void setDiseasedId(UUID diseasedId) {
		this.diseasedId = diseasedId;
	}
/**
 * The getName returns the name of the current object.
 * @return
 */
	public String getName() {
		return name;
	}
/**
 * The setName initializes the name with provided name of String type.
 * @param name
 */
	public void setName(String name) {
		this.name = name;
	}

}
/**
 * The InfectiousDisease class creates a kind of relationship with Disease.
 * @author Dell
 *
 */
class InfectiousDisease extends Disease {

	@Override
	String getExamples() {
		String diseases[] = { "Influenza", "Malaria", "Measles", "COVID-19" };
		for (String disease : diseases) {
			return disease;
		}
		return null;
	}
}
/**
 * The NonInfectiousDisease class creates a kind of relationship with Disease.
 * @author Dell
 *
 */
class NonInfectiousDisease extends Disease {

	@Override
	String getExamples() {
		String diseases[] = { "Cancer", "Diabeties", "Stroke", "Asthma" };
		for (String disease : diseases) {
			return disease;
		}
		return "";
	}
}
