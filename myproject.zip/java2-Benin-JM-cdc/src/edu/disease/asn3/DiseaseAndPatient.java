package edu.disease.asn3;

/**
 * The DiseaseAndPatient class contains the arrays of Disease and Patient objects.
 */
public class DiseaseAndPatient {
	private Disease[] diseases;
	private Patient[] patients;

	/**
	 * Get the array of Disease objects.
	 *
	 * @return The array of Disease objects.
	 */
	public Disease[] getDiseases() {
		return diseases;
	}

	/**
	 * Set the array of Disease objects.
	 *
	 * @param diseases The array of Disease objects to be set.
	 */
	public void setDiseases(Disease[] diseases) {
		this.diseases = diseases;
	}

	/**
	 * Get the array of Patient objects.
	 *
	 * @return The array of Patient objects.
	 */
	public Patient[] getPatients() {
		return patients;
	}

	/**
	 * Set the array of Patient objects.
	 *
	 * @param patients The array of Patient objects to be set.
	 */
	public void setPatients(Patient[] patients) {
		this.patients = patients;
	}

}
