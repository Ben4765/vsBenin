package edu.disease.asn3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * The DiseaseFileRepository class provides methods to save and initialize
 * Disease and Patient objects.
 * 
 * @author Dell
 *
 */
public class DiseaseFileRepository {
	String folderPath;

	/**
	 * Saves Disease and Patient objects to separate files.
	 * 
	 * @param diseases
	 * @param patients
	 * @throws IOException If an I/O error occurs while writing to files.
	 */
	void save(Disease[] diseases, Patient[] patients) throws IOException {
		FileOutputStream diseaseFile = new FileOutputStream("diseases.dat");
		ObjectOutputStream diseaseObject = new ObjectOutputStream(diseaseFile);
		diseaseObject.writeObject(diseases);
		diseaseObject.close();

		FileOutputStream patientFile = new FileOutputStream("patients.dat");
		ObjectOutputStream patientObject = new ObjectOutputStream(patientFile);
		patientObject.writeObject(patients);
		patientObject.close();
	}

	/**
	 * Initializes Disease and Patient objects from specified folder path.
	 * 
	 * @return An instance of DiseaseAndPatient containing the initialized arrays.
	 * @throws IOException              If an I/O error occurs while reading files.
	 * @throws ClassNotFoundException 	If a class of a serialized object cannot be
	 *                                  found.
	 * @throws IllegalArgumentException If the folderPath parameter is null.
	 */
	DiseaseAndPatient init(String folderPath) throws IOException, ClassNotFoundException {
		DiseaseAndPatient obj = new DiseaseAndPatient();
		if (folderPath != null) {

			FileInputStream diseaseFile = new FileInputStream(folderPath + "\\disease.dat");
			ObjectInputStream diseaseObject = new ObjectInputStream(diseaseFile);
			obj.setDiseases((Disease[]) diseaseObject.readObject());
			diseaseFile.close();

			FileInputStream patientFile = new FileInputStream(folderPath + "\\patient.dat");
			ObjectInputStream patientObject = new ObjectInputStream(patientFile);
			obj.setPatients((Patient[]) patientObject.readObject());
			patientObject.close();
		} else
			throw new IllegalArgumentException();
		return obj;

	}
}
