package edu.disease.asn4;

import edu.disease.asn3.DiseaseControlManager;
import edu.disease.asn3.Exposure;
import edu.disease.asn3.Patient;

public class ContactTrace {
	Exposure earlyExposure;
	Patient[] patients;
	PatientZero pz;

	public ContactTrace(DiseaseControlManager diseaseControlManager) {
		this.patients = diseaseControlManager.getPatients();

	}

	PatientZero findPatientZero(Patient patient) {
		for (Exposure exposure : patient.getExposures()) {
			if (exposure.getExposureType().equalsIgnoreCase("D")) {
				if (earlyExposure == null || exposure.getDateTime().isBefore(earlyExposure.getDateTime())) {
					earlyExposure = exposure;

				}
			}
		}
		if (earlyExposure != null) {
			for (Patient p : this.patients) {
				for (Exposure exposure : p.getExposures()) {
					if (exposure.getExposureType().equalsIgnoreCase("D")) {
						if (exposure.getDateTime().isBefore(earlyExposure.getDateTime())) {
							earlyExposure = exposure;
							pz.setExposed(true);
							pz.setExposureDateTime(exposure.getDateTime());
							pz.setPatient(p);
							return findPatientZero(p);
						}
					}
				}
			}
		}
		return pz;
	}

}
