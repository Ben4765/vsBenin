package edu.disease.asn5;

public class Container<T> {
	Object o;
	int size;
	public Container(Object... o) {
		this.o=o;
		this.size=o.length;
	}
	int size() {
		return size;
	}
	public <T>Object get(int index){
		try {
			if(index>size) 
				throw new IllegalArgumentException();
			else {
				
			}
			
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
		
	}
	
}
