package edu.disease.asn3;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

class DiseaseFileRepositoryTest {

	@Test
	void testA() throws IOException {
		DiseaseFileRepository dfr=new DiseaseFileRepository();
		Disease []d=new Disease[2];
		Patient []p=new Patient[2];
		dfr.save(d, p);
		
	}

}
