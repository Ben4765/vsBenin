package edu.disease.asn4;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.disease.asn3.Patient;

class ContactTraceTest {

	@Test
	void testContactTrace() {
		PatientZero pz=new PatientZero();
		pz.setPatient(new Patient(1, 1));
		pz.
	}

	@Test
	void testFindPatientZero() {
		fail("Not yet implemented");
	}

}
