package dao;

import java.sql.SQLException;

interface UserDAOInter {
	String valid(String name, String pass)throws SQLException;
	void create(UserData user)throws SQLException;
	void updateFlag(int i);
	
}
