package edu.disease.asn2;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.UUID;

import org.hamcrest.core.IsInstanceOf;
import org.junit.jupiter.api.Test;

import edu.disease.asn1.Exposure;
import edu.disease.asn1.Patient;

class PatientTest {
	@Test
	public void atest() throws IOException {
		Patient p = new Patient(2, 2);
		// p.addDiseaseId(UUID.randomUUID());
		p.addExposure(new Exposure(UUID.randomUUID()));
		Exposure[] e = p.getExposures();
//		for(Exposure e1:e) {
//			System.out.println(e1);
//		}
		assertTrue(e[0] instanceof Exposure && e[1] == null);
	}

	@Test
	public void btest() throws IOException {
		Patient p = new Patient(2, 2);
		// p.addDiseaseId(UUID.randomUUID());
		p.addExposure(new Exposure(UUID.randomUUID()));
		p.addExposure(new Exposure(UUID.randomUUID()));
		Exposure[] e = p.getExposures();
//		for(Exposure e1:e) {
//			System.out.println(e1);
//		}
		assertTrue(e[0] instanceof Exposure && e[1] instanceof Exposure);
	}

	@Test
	public void ctest() {
		Patient p = new Patient(2, 2);
		// p.addDiseaseId(UUID.randomUUID());
		p.addExposure(new Exposure(UUID.randomUUID()));
		p.addExposure(new Exposure(UUID.randomUUID()));
		assertThrows(IndexOutOfBoundsException.class, () -> p.addExposure(new Exposure(UUID.randomUUID())));

	}

	@Test
	public void dtest() {
		Patient p = new Patient(2, 2);
		p.addDiseaseId(UUID.randomUUID());
		UUID[] p1 = p.getDiseaseIds();
		assertTrue(p1[1] == null);

	}

	@Test
	public void etest() {
		Patient p = new Patient(2, 2);
		p.addDiseaseId(UUID.randomUUID());
		p.addDiseaseId(UUID.randomUUID());

		UUID[] p1 = p.getDiseaseIds();
		assertTrue(p1[0] instanceof UUID && p1[1] instanceof UUID);
	}

	@Test
	public void constructor() {
		assertThrows(IllegalArgumentException.class, () -> new Patient(-1, 0));
	}

	@Test
	public void ftest() {
		Patient p = new Patient(2, 2);
		p.addDiseaseId(UUID.randomUUID());
		p.addDiseaseId(UUID.randomUUID());
		assertThrows(IndexOutOfBoundsException.class, () -> p.addDiseaseId(UUID.randomUUID()));
	}
	@Test void testName() {
		Patient p = new Patient(2, 2);
		p.setFirstName("Ben");
		assertEquals("Ben",p.getFirstName());
	}
}
